<template>
    这是互动消息
</template>

<script>
export default {

}
</script>

<style>

</style>