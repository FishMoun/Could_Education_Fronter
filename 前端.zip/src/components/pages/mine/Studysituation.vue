<template>
    这里是学习情况
</template>

<script>
export default {

}
</script>

<style>

</style>