服务外包项目前端代码

Vue3 + vite + js + elementplus

开发参考网站（官网的示例代码是用ts写的，复制粘贴须谨慎）：

Vue3官方：https://cn.vuejs.org/ 

Elementplus官方：https://element-plus.gitee.io/zh-CN/


运行方式（电脑需要安装node16）：

1、npm install 构建
2、npm run dev 启动
3、按q结束服务器

前端开发规范：组件的首字母大写，路由的name里面的都用小写
