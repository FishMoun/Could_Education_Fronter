<template></template>
  
  <script>
import { defineComponent } from "vue";

export default defineComponent({
  components: {
    VideoPlayer,
  },

  data() {
    return {
      playingtime: "",
    };
  },
  methods: {},
});
</script>