<template>
  <!-- 节次学习 -->
  <div class="classlearningcontent">
    <!-- 节次学习左侧资源区 -->
    <el-scrollbar class="left">
      <!-- 左上本节概要区 -->
      <div class="classintroduction">
        <el-button @click="changerole" style="position: absolute; left: 0"
          >当前是{{ isTeacher ? "老师" : "学生" }}模式</el-button
        >
        <el-card shadow="never" class="introduction-card">
          <div style="font-size: 20px">本节概要:</div>
          <div v-if="introduction != ''">
            <p>{{ introduction }}</p>
          </div>
          <el-button
            style="margin-top: 10px"
            link
            type="primary"
            v-show="isTeacher == true"
            @click="editcontent"
            >编辑</el-button
          >
          <!-- 编辑内容的对话框 -->
          <el-dialog
            v-model="editcontentdialogVisible"
            title="本节概要"
            width="30%"
          >
            <el-input
              v-model="editintroduction"
              :rows="5"
              type="textarea"
              placeholder="输入内容"
              resize="none"
            />
            <template #footer>
              <span class="dialog-footer">
                <el-button @click="editcontentdialogVisible = false"
                  >取消</el-button
                >
                <el-button type="primary" @click="submitIntroduction">
                  确定
                </el-button>
              </span>
            </template>
          </el-dialog>
        </el-card>
      </div>
      <!-- 主要资源区，用折叠面板实现 -->
      <div style="margin-left: 10px; height: 70vh">
        <el-collapse v-model="activeNames" accordion>
          <el-collapse-item name="1">
            <template #title>
              <div class="header">课堂课件</div>
            </template>
            <!-- PPT资源操作 -->
            <div class="button-wrapper">
              <el-upload
                style="display: inline-block"
                class="upload-demo"
                :action="uploadPPTUrl"
                :on-success="handleSuccessPPT"
                :on-error="handleErr"
                :on-progress="handleprogress"
                :headers="{ token: this.$store.state.token }"
                :show-file-list="false"
              >
                <template #trigger>
                  <el-button
                    style="margin-left: 10px; margin-top: 10px"
                    type="primary"
                    v-show="isTeacher == true"
                    >上传</el-button
                  >
                </template>
              </el-upload>
              <a :href="this.PPTUrl">
                <el-button
                  style="margin-left: 10px; margin-top: 10px"
                  type="primary"
                  v-show="isPPTExist === true"
                  @click="downloadPPT"
                  >下载
                </el-button>
              </a>
              <el-button
                style="margin-left: 10px; margin-top: 10px"
                type="danger"
                v-show="isTeacher === true && isPPTExist === true"
                @click="deletePPT"
                >删除</el-button
              >
            </div>
            <div v-show="isPPTExist">
              <div class="pptzone">
                <canvas :id="'the-canvas' + num"></canvas>
              </div>
              <div class="pptoperatebar">
                <el-button @click="previous">上一页</el-button>
                <div>{{ num }}/{{ pages }}</div>
                <div>
                  <el-button @click="zoomin">放大</el-button>
                  <el-button @click="zoomout">缩小</el-button>
                  <el-button @click="next">下一页</el-button>
                </div>
              </div>
            </div>
          </el-collapse-item>
          <el-collapse-item name="2">
            <template #title> <div class="header">教学视频</div> </template>
            <!-- 视频资源操作 -->
            <div class="button-wrapper">
              <el-upload
                :show-file-list="false"
                style="display: inline-block"
                class="upload-demo"
                :action="uploadVideoUrl"
                :on-success="handleSuccessVideo"
                :on-error="handleErr"
                :on-progress="handleprogress"
                :headers="{ token: this.$store.state.token }"
              >
                <template #trigger>
                  <el-button
                    style="margin-left: 10px; margin-top: 10px"
                    type="primary"
                    v-show="isTeacher == true"
                    >上传</el-button
                  >
                </template>
              </el-upload>
              <el-button
                style="margin-left: 10px; margin-top: 10px"
                type="danger"
                v-show="isTeacher === true && isVideoExist === true"
                @click="deleteVideo"
                >删除</el-button
              >
              <a :href="videoUrl">
                <el-button
                  style="margin-left: 10px; margin-top: 10px"
                  type="primary"
                  v-show="isVideoExist === true"
                  @click="downloadPPT"
                  >下载
                </el-button>
              </a>
            </div>
            <div class="videozone" v-show="isVideoExist">
              <video-player
                :src="videoUrl"
                @loadeddata="logtime($event)"
                controls
                :disablePictureInPicture="true"
                :playback-rates="[0.5, 1.0, 1.5, 2.0]"
                :volume="0.6"
              />
            </div>
          </el-collapse-item>
          <el-collapse-item name="3">
            <template #title>
              <div class="header">共享资源</div>
            </template>
            <!-- 共享资源操作 -->

            <el-upload
              class="upload-demo"
              :action="uploadShareUrl"
              :on-success="handleSuccessShare"
              :on-error="handleErr"
              :on-progress="handleprogress"
              list-type="picture"
              :show-file-list="false"
              :headers="{ token: this.$store.state.token }"
            >
              <template #trigger>
                <el-button
                  style="margin-left: 10px; margin-top: 10px"
                  type="primary"
                  >上传</el-button
                >
              </template>
              <template #file="{ file }">
                <img
                  class="el-upload-list__item-thumbnail"
                  :src="getFileImage(file.name)"
                  alt=""
                />

                <span class="el-upload-list__item-file-name">{{
                  file.name
                }}</span>
                <div class="fileicon">
                  <el-icon
                    size="20px"
                    v-show="isTeacher"
                    @click="deleteShare(file.id)"
                    style="cursor: pointer"
                    ><Delete
                  /></el-icon>
                  <a :href="file.url"
                    ><el-icon size="20px" color=""><Download /></el-icon
                  ></a>
                </div>
              </template>
            </el-upload>

            <el-card
              shadow="never"
              v-for="item in sharefileList"
              :key="item.id"
              v-show="sharefileList.length !== 0"
              style="margin: 10px"
            >
              <div class="filelist">
                <div style="display: flex; align-items: center">
                  <img
                    style="width: 70px; height: 70px"
                    :src="getFileImage(item.name)"
                    alt=""
                  />

                  <span>{{ item.name }}</span>
                </div>
                <div class="fileicon">
                  <el-icon
                    size="20px"
                    v-show="isTeacher"
                    @click="deleteShare(item.id)"
                    style="cursor: pointer"
                    ><Delete
                  /></el-icon>
                  <a :href="item.url"
                    ><el-icon size="20px" color=""><Download /></el-icon
                  ></a>
                </div>
              </div>
            </el-card>
          </el-collapse-item>
        </el-collapse>
      </div>
    </el-scrollbar>
    <div>
      <!-- 折叠元素 -->
      <el-button link @click="collapsediscusszone"
        ><el-icon v-if="isDiscusszoneCollapse"><DArrowLeft /></el-icon>
        <el-icon v-else> <DArrowRight /></el-icon>
      </el-button>
    </div>
    <!-- 右侧讨论区 -->
    <transition>
      <div class="discusszone" v-show="isDiscusszoneCollapse == false">
        <!-- 讨论区标题 -->
        <el-header>
          <el-card
            shadow="never"
            style="margin-top: 10px; text-align: center; min-height: 100%"
          >
            <div style="font-size: 24px">讨论区</div>
          </el-card>
        </el-header>
        <!-- 讨论区主体 -->
        <el-main style="height: 95%">
          <!-- 讨论卡片 -->
          <el-card shadow="never" style="height: 90%; padding: 0">
            <div class="inputzone">
              <el-input
                v-model="mydiscussion"
                autosize
                type="textarea"
                placeholder="发布讨论"
                resize="none"
              />
              <el-button
                type="primary"
                style="margin-left: 10px"
                @click="submitcurrentPPTdiscussion"
                >发布</el-button
              >
            </div>
            <div
              style="margin-bottom: 5px"
              v-show="activeNames == '1' && isPPTExist"
            >
              <el-button link>全部</el-button>
              <el-divider direction="vertical" />
              <el-button link style="margin-left: 0"
                >看当前第{{ num }}页</el-button
              >
            </div>
            <el-scrollbar height="66vh">
              <el-card
                class="discussion-card"
                shadow="never"
                v-for="(item, value) in discusslist"
                :key="value"
              >
                <div class="userinfo">{{ item.name }}</div>
                <div class="userdiscussion">
                  <p>{{ item.content }}</p>
                </div>
                <div class="usercredit">
                  <div>{{ item.date }}</div>
                  <div class="credit-right">
                    <div style="margin-right: 5px">
                      <el-button link>
                        <el-icon>
                          <svg class="icon" aria-hidden="true">
                            <use xlink:href="#icon-dianzan"></use>
                          </svg>
                        </el-icon>
                      </el-button>
                      {{ item.creditnum }}
                    </div>
                    <el-button link @click="item.replyvisible = true"
                      >回复</el-button
                    >
                  </div>
                </div>
                <div class="replyinput" v-show="item.replyvisible">
                  <el-input
                    v-model="mydiscussion"
                    autosize
                    type="textarea"
                    placeholder="写回复"
                    resize="none"
                    style="width: 70%"
                  />
                  <el-button
                    type="primary"
                    style="margin-left: 10px; height: 30px"
                    >回复</el-button
                  >
                  <el-button link @click="item.replyvisible = false"
                    ><el-icon><CloseBold /></el-icon
                  ></el-button>
                </div>
                <el-divider
                  style="margin: 5px"
                  v-show="item.replycard.length !== 0"
                />
                <div
                  class="userrelpy"
                  v-for="(subitem, subvalue) in item.replycard"
                  :key="subvalue"
                >
                  <el-card
                    shadow="never"
                    class="replycard"
                    body-style="padding:0 0 0 5px "
                  >
                    <div class="userinfo">{{ subitem.name }}</div>
                    <div class="userdiscussion">
                      <p>{{ subitem.content }}</p>
                    </div>
                    <div class="usercredit">
                      <div>{{ subitem.date }}</div>
                      <div class="credit-right">
                        <div style="margin-right: 5px">
                          <el-button link>
                            <el-icon>
                              <svg class="icon" aria-hidden="true">
                                <use xlink:href="#icon-dianzan"></use>
                              </svg>
                            </el-icon>
                          </el-button>
                          {{ subitem.creditnum }}
                        </div>
                      </div>
                    </div></el-card
                  >
                </div>
              </el-card>
            </el-scrollbar></el-card
          ></el-main
        >
      </div>
    </transition>
  </div>
</template>

<script>
//video引入
import { VideoPlayer } from "@videojs-player/vue";
import "video.js/dist/video-js.css";
//pdf引入
import * as pdfjsLib from "pdfjs-dist";
import { toRaw } from "vue";
import { ElMessage } from "element-plus";
import { Download } from "@element-plus/icons-vue";
export default {
  name: "Classlearning",
  components: {
    VideoPlayer,
  },
  data() {
    return {
      //视频播放时间
      playingtime: "",
      isPPTExist: false,
      isVideoExist: false,
      isShareExist: false,
      PPTId: [],
      PPTUrl: "",
      videoId: "",
      videoUrl: "",
      shareId: [],
      shareUrl: [],
      PPTfileList: [],
      videofileList: [],
      sharefileList: [],
      title: "查看协议",
      pdfDoc: null,
      pages: 0,
      num: 1,
      mydiscussion: "",
      //控制画布放大缩小
      myscale: 0.6,
      //节次介绍的内容
      introduction: "",
      //正在编辑的节次介绍的内容
      editintroduction: "",
      //编辑介绍的对话框
      editcontentdialogVisible: false,
      //折叠讨论区
      isDiscusszoneCollapse: false,
      //左侧折叠面板的打开情况
      activeNames: "",
      //评论卡片
      discusslist: [
        // {
        //   name: "秦岭",
        //   content: "你好",
        //   date: "两天前",
        //   creditnum: "2",
        //   replyvisible: false,
        //   replycard: [
        //     {
        //       name: "葛天辰",
        //       content: "你也好",
        //       date: "一天前",
        //       creditnum: "1",
        //     },
        //     {
        //       name: "韩耀杰",
        //       content: "你也好",
        //       date: "一天前",
        //       creditnum: "1",
        //     },
        //   ],
        // },
        // {
        //   name: "李锴凌",
        //   content: "你好",
        //   date: "两天前",
        //   creditnum: "2",
        //   replyvisible: false,
        //   replycard: [
        //     {
        //       name: "陈佩沛",
        //       content: "你也好",
        //       date: "一天前",
        //       creditnum: "1",
        //     },
        //   ],
        // },
        // {
        //   name: "秦岭",
        //   content: "你好",
        //   date: "两天前",
        //   creditnum: "2",
        //   replyvisible: false,
        //   replycard: [
        //     {
        //       name: "葛天辰",
        //       content: "你也好",
        //       date: "一天前",
        //       creditnum: "1",
        //     },
        //     {
        //       name: "韩耀杰",
        //       content: "你也好",
        //       date: "一天前",
        //       creditnum: "1",
        //     },
        //   ],
        // },
      ],
    };
  },
  computed: {
    isTeacher() {
      return this.$store.state.isTeacher;
    },
    //PPT上传地址
    uploadPPTUrl() {
      return `http://60.204.141.214:30900/manager/course-resource/upload-timetable/ppt/${this.$route.params.courseId}/${this.$route.params.classId}`;
    },
    //视频上传地址
    uploadVideoUrl() {
      return `http://60.204.141.214:30900/manager/course-resource/upload-timetable/video/${this.$route.params.courseId}/${this.$route.params.classId}`;
    },
    //共享资源上传地址
    uploadShareUrl() {
      return `http://60.204.141.214:30900/manager/course-resource/upload-timetable/share/${this.$route.params.courseId}/${this.$route.params.classId}`;
    },
    courseId() {
      return this.$route.params.courseId;
    },
    classId() {
      return this.$route.params.classId;
    },
    userId() {
      return this.$store.state.userInfo.id;
    },
  },
  watch: {
    isPPTExist(newVal) {
      if (newVal) this._loadFile(this.PPTUrl);
    },
  },
  async mounted() {
    this.initThePDFJSLIB();
    let ppturl = await this.getClassPPTUrl();
    if (ppturl) {
      this.PPTUrl = ppturl;
      this.isPPTExist = true;
      await this.getDiscussionById(this.PPTId[0]);
    }

    this.$nextTick(() => {
      this.activeNames = "1";
    });

    let videourl = await this.getClassVideoUrl();
    if (videourl) {
      this.videoUrl = videourl;
      this.isVideoExist = true;
    }
    await this.getClassShareUrl();
  },
  methods: {
    //下载PPT
    async downloadPPT() {},
    //删除PPT
    async deletePPT() {
      let isSuccess = true;
      for (let i = 0; i < this.PPTId.length; i++) {
        let res = await this.$request(
          `/manager/course-resource/delete/${this.courseId}/${this.PPTId[i]}`,
          "",
          "delete",
          "params",
          "json"
        );
        if (res?.data.code !== 20000) isSuccess = false;
      }
      if (isSuccess) {
        this.isPPTExist = false;
        ElMessage.success("删除成功！");
      } else {
        ElMessage.error("删除失败，请稍后重试！");
      }
    },
    //删除视频
    async deleteVideo() {
      let res = await this.$request(
        `/manager/course-resource/delete/${this.courseId}/${this.videoId}`,
        "",
        "delete",
        "params",
        "json"
      );
      if (res && res?.data.code === 20000) {
        this.isVideoExist = false;
        ElMessage.success("删除成功！");
      } else {
        ElMessage.error("删除失败，请稍后重试！");
      }
    },
    //删除共享资源
    async deleteShare(id) {
      let res = await this.$request(
        `/manager/course-resource/delete/${this.courseId}/${id}`,
        "",
        "delete",
        "params",
        "json"
      );
      if (res && res?.data.code === 20000) {
        this.isShareExist = false;
        await this.getClassShareUrl();
        console.log(this.sharefileList);
        ElMessage.success("删除成功！");
      } else {
        ElMessage.error("删除失败，请稍后重试！");
      }
    },
    //获取小节PPT的url
    async getClassPPTUrl() {
      let params = {
        classId: this.$route.params.classId,
      };
      let res = await this.$request(
        "/manager/course-resource/get-timetable/ppt",
        params,
        "get",
        "resful",
        "json"
      );
      console.log(res);
      let url;
      if (res?.data.code === 20000 && res.data.data.files.length !== 0) {
        let item = res.data.data.files?.find((item) => item.type === "pdf");
        url = item.url;
        this.PPTId = res.data.data?.resource.map((item) => item.id);
      }

      if (url) return url;
      else return null;
    },
    //获取视频的url
    async getClassVideoUrl() {
      let params = {
        classId: this.$route.params.classId,
      };
      let res = await this.$request(
        "/manager/course-resource/get-timetable/video",
        params,
        "get",
        "resful",
        "json"
      );
      console.log("resvideo", res);
      let url;
      if (res) {
        if (res.data.code === 20000 && res.data.data.urls.length !== 0) {
          let item = res.data.data.urls;
          url = item[0];
          this.videoId = res.data.data.resources[0].id;
        }
      }
      if (url) return url;
      else return null;
    },
    //获取共享资源的url
    async getClassShareUrl() {
      let params = {
        classId: this.$route.params.classId,
      };
      let res = await this.$request(
        "/manager/course-resource/get-timetable/share",
        params,
        "get",
        "resful",
        "json"
      );
      console.log("resshare", res);
      if (res) {
        if (res.data.code === 20000 && res.data.data.files.length !== 0) {
          this.sharefileList = res.data.data.files.map((item, index) => {
            return {
              url: item.url,
              name: item.name + "." + item.type,
              type: item.type,
              id: res.data.data.resources[index].id,
            };
          });
          this.shareId = res.data.data.resources.map((item) => item.id);
        } else {
          this.sharefileList = [];
        }
      }
    },
    //文件上传回调
    async handleSuccessPPT(res) {
      console.log(res);
      if (res && res.code === 20000) {
        ElMessage.success("上传成功!");
        this.PPTUrl = await this.getClassPPTUrl();
        this.isPPTExist = true;
      } else ElMessage.success("上传失败，请稍后重试");
    },
    async handleSuccessVideo(res) {
      if (res && res.code === 20000) {
        ElMessage.success("上传成功!");
        this.isVideoExist = true;
      } else ElMessage.success("上传失败，请稍后重试");
    },
    async handleSuccessShare(res) {
      if (res && res.code === 20000) {
        ElMessage.success("上传成功!");
        await this.getClassShareUrl();
        this.isShareExist = true;
      } else ElMessage.success("上传失败，请稍后重试");
    },
    handleprogress(p) {
      console.log("p");
      console.log(p);
    },
    handleErr(err) {
      console.log("err");
      console.log(err);
      ElMessage.success("上传失败，请稍后重试");
    },
    // 初始化pdfjs
    initThePDFJSLIB: function () {
      pdfjsLib.GlobalWorkerOptions.workerSrc = "/src/plugins/pdf.worker.js";
    },
    /* pdf渲染 */
    _renderPage(num) {
      toRaw(this.pdfDoc)
        .getPage(num)
        .then((page) => {
          let canvas = document.getElementById("the-canvas" + num);
          let ctx = canvas.getContext("2d");
          const viewport = page.getViewport({ scale: this.myscale });
          var CSS_UNITS = 96.0 / 72.0;
          canvas.height = Math.floor(viewport.height * CSS_UNITS);
          canvas.width = Math.floor(viewport.width * CSS_UNITS);
          // 画布的dom大小, 设置移动端,宽度设置铺满整个屏幕
          const clientWidth = canvas.width;
          canvas.style.width = clientWidth + "px";
          // 根据pdf每页的宽高比例设置canvas的高度
          canvas.style.height =
            clientWidth * (canvas.height / canvas.width) + "px";
          page.render({
            transform: [CSS_UNITS, 0, 0, CSS_UNITS, 0, 0],
            canvasContext: ctx,
            viewport,
          });
        });
    },
    /* 获取pdf相关信息 */
    _loadFile(url) {
      const loadingTask = pdfjsLib.getDocument(url);
      loadingTask.promise.then((pdf) => {
        this.pdfDoc = pdf;
        this.pages = pdf.numPages;
        this.$nextTick(() => {
          this._renderPage(1);
        });
      });
    },
    /* 下一页 */
    next() {
      if (this.num < this.pages) {
        this.num++;
        this._renderPage(this.num);
      }
    },
    /* 上一页 */
    previous() {
      if (this.num !== 1) {
        this.num--;
        this._renderPage(this.num);
      }
    },
    // 放大
    zoomin() {
      if (this.myscale > 1.1) ElMessage("已经是最大了");
      else {
        this.myscale += 0.1;
        this._renderPage(this.num);
      }
    },
    // 缩小
    zoomout() {
      if (this.myscale < 0.3) ElMessage("已经是最小了");
      else {
        this.myscale -= 0.1;
        this._renderPage(this.num);
      }
    },
    changerole() {
      this.$store.state.isTeacher = !this.$store.state.isTeacher;
    },
    //编辑介绍内容
    editcontent() {
      this.editcontentdialogVisible = true;
    },
    //提交内容
    submitIntroduction() {
      this.introduction = this.editintroduction;
      this.editcontentdialogVisible = false;
    },
    //折叠讨论区
    collapsediscusszone() {
      this.isDiscusszoneCollapse = !this.isDiscusszoneCollapse;
    },
    //视频记录秒数
    logtime(playingtime) {
      this.playingtime = playingtime;
      console.log(playingtime);
    },
    //对资源的某一页发表评论
    async submitcurrentPPTdiscussion() {
      if (this.mydiscussion) {
        let params = {
          content: this.mydiscussion,
          page: this.num,
          resourceId: this.PPTId[0],
          userId: this.userId,
        };
        let res = await this.$request(
          "/manager/course-discussion/issue",
          params,
          "post",
          "params",
          "json"
        );

        console.log("sumbit", res);
        if (res && res.data.code === 20000) {
          ElMessage.success("发布成功！");
          this.mydiscussion = "";
        }
        this.getDiscussionById(this.PPTId[0]);
      } else {
        ElMessage.error("输入内容不能为空！");
      }
    },
    //根据资源Id查询讨论
    async getDiscussionById(resourceId) {
      let res = await this.$request(
        `/manager/course-discussion/list-all/${resourceId}`,
        "",
        "get",
        "params",
        "json"
      );
      console.log(res);
      let tmpdiscusslist;
      if (res && res.data.code === 20000) {
        if (res.data.data.discussions.length !== 0) {
          tmpdiscusslist = res.data.data.discussions.map((item) => {
            return {
              name: item.userName,
              content: item.content,
              creditnum: item.likes,
              replyvisible: false,
              date: item.sendTime,
              replycard: item.replies.map((item) => item),
            };
          });
          this.discusslist = JSON.parse(JSON.stringify(tmpdiscusslist));
        }
      }
      // {
      //   name: "秦岭",
      //   content: "你好",
      //   date: "两天前",
      //   creditnum: "2",
      //   replyvisible: false,
      //   replycard: [
      //     {
      //       name: "葛天辰",
      //       content: "你也好",
      //       date: "一天前",
      //       creditnum: "1",
      //     },
      //     {
      //       name: "韩耀杰",
      //       content: "你也好",
      //       date: "一天前",
      //       creditnum: "1",
      //     },
      //   ],
      // },
    },
    //资源缩略图
    getFileImage(name) {
      if (name.includes("pdf")) return "/src/assets/img/pdf.png";
      else if (name.includes("ppt")) return "/src/assets/img/ppt.png";
      else if (name.includes("txt")) return "/src/assets/img/txt.png";
      else if (name.includes("zip")) return "/src/assets/img/zip.png";
      else if (name.includes("doc")) return "/src/assets/img/word.png";
      else return "/src/assets/img/word.png";
    },
  },
};
</script>

<style scoped>
.el-header {
  height: auto;
  padding-left: 0;
}
.el-main {
  padding-top: 10px;
  padding-left: 0;
}
canvas {
  display: block;
  border-bottom: 1px solid black;
}
.pptoperatebar {
  display: flex;
  justify-content: space-around;
}
.canvasbox {
  border: 1px solid;
  width: fit-content;
}
.left {
  width: 100%;
  height: 80vh;
}
.discusszone {
  width: 30vw;
  height: 90vh;
}
.pptzone {
  display: flex;
  justify-content: center;
}
.header {
  margin-left: 10px;
}
.classintroduction {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}
.classlearningcontent {
  display: flex;
}
.introduction-card {
  width: 30vw;
  min-height: 10vh;
  margin-bottom: 10px;
}
.inputzone {
  display: flex;
  flex-direction: row;
  margin-bottom: 2px;
}
.userinfo {
  color: #606266;
  font-size: 15px;
  margin-bottom: 5px;
}
.userdiscussion {
  margin-bottom: 5px;
}
.usercredit {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  color: #909399;
  font-size: 15px;
  margin-bottom: 5px;
}
.credit-right {
  display: flex;
  flex-direction: raw;
  align-items: center;
}
.videozone {
  display: flex;
  justify-content: center;
}
.replyinput {
  display: flex;
}
/* 回复卡片 */
.replycard {
  border: 0;
  padding: 0px;
}
.discussion-card {
  margin-bottom: 10px;
}
.button-wrapper {
  display: flex;
}
.fileicon {
  display: flex;
  flex-direction: column;
  height: 100%;
  justify-content: space-around;
}
.filelist {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style>