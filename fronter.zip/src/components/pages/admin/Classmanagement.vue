<template>
  <el-container>
    <!-- 头部筛选区 -->
    <el-header> </el-header>
    <!-- 主体表格区 -->
    <el-main>
      <el-table v-loading="loading" :data="tableData" table-layout="fixed">
        <el-table-column prop="classId" label="班级ID" />
        <el-table-column prop="name" label="名称" />
        <el-table-column prop="college" label="学院" />
        <el-table-column prop="major" label="专业" />
        <el-table-column fixed="right" label="操作" width="200px">
          <template #default="{ row }">
            <el-button type="primary">编辑</el-button>
            <el-button type="danger" @click="deleteClassById(row.classId)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </el-main>
  </el-container>
</template>
  
  <script>
export default {
  data() {
    return {
      loading: false,
      tableData: [],
    };
  },
  methods: {
    //查询所有的班级信息
    async getAllClassInfo() {
      let res = await this.$request(
        "/admin/manager/class/list",
        "",
        "get",
        "params",
        "json"
      );
      let classes = res?.data.data.classes;
      for (let i = 0; i < classes.length; ++i) {
        this.tableData[i] = {
          classId: classes[i].id,
          name: classes[i].name,
          college: classes[i].department,
          major: classes[i].major,
        };
      }
    },
    async deleteClassById(classId) {
      let tmpparams = {
        id: classId,
      };
      let res = await this.$request(
        "/admin/manager/class/remove",
        tmpparams,
        "delete",
        "params",
        "json"
      );
      this.getAllClassInfo();
    },
  },
  mounted() {
    //初始化学生列表
    this.getAllClassInfo();
  },
};
</script>
  
  <style>
</style>